## Bọn em là TA_Chatbot. Bọn em giúp sinh viên CS năm nhất giải quyết việc kẹt lỗi lập trình đêm muộn bằng trợ giảng AI hybrid bám sát giáo trình, có trích dẫn nguồn.

## Hiện đã có 70% feedback hữu ích. LTV/CAC = 10.9x, payback 1.8 tháng.

## Đang gọi 500M VND để mở rộng quy mô phục vụ toàn bộ sinh viên CS trong 12 tháng.
# 1. Toàn bộ feedback của AI VC

8-Second Test (FAIL): Câu chuyện 2h sáng là "vitamin", không phải "painkiller". Thiếu yếu tố quy mô và khả năng phòng thủ.
Insight Test (GENERIC): Trích dẫn slide là tính năng RAG cơ bản.
NotebookLM của Google đã làm tốt hơn và miễn phí.
Moat (Weak): "Wrapper startup" dễ bị OpenAI/Google nghiền nát nếu không có rào cản phân phối hoặc dữ liệu độc quyền.
Numbers: LTV/CAC >3 cho sinh viên năm nhất là số liệu thiếu thực tế không tính đến tính thời vụ và sự rời bỏ sau kỳ học.
Weakest Line: "Hệ thống Hybrid bảo mật" là từ ngữ sáo rỗng với mức vốn 500 triệu VNĐ.

# 2. Quyết định Accept / Reject / Partial từng điểm
REJECT Insight trích dẫn: Loại bỏ việc coi RAG là điểm khác biệt cốt lõi.
ACCEPT Phê bình Moat: Chấp nhận rằng việc chỉ có app là không đủ; cần tập trung vào tích hợp hệ thống (LMS).
PARTIAL The Hook: Giữ lại bối cảnh sinh viên nhưng chuyển từ "debug hộ" sang "gợi ý sư phạm" (Socratic hints) để lấy lòng giảng viên.
ACCEPT Chiến lược vốn: Thay đổi mục tiêu dùng vốn từ "xây hệ thống hybrid" sang "chiếm lĩnh độc quyền dữ liệu khoa".

# 3. Pitch final đã sửa

# Pitch Mới:
Thay vì đưa đáp án, TA_Chatbot cung cấp "Socratic hints" dẫn dắt sinh viên CS tự
debug dựa trên đúng giáo trình của khoa IT. Chúng tôi không chỉ giải quyết nỗi đau
của sinh viên lúc 2h sáng, mà còn giải quyết nỗi lo vi phạm chính sách học thuật
của giảng viên.
# Key Update:
Đã thỏa thuận tích hợp thử nghiệm vào hệ thống LMS của khoa IT, tạo rào cản phòng
thủ bằng dữ liệu bài tập nội bộ mà các mô hình lớn (GPT/Gemini) không có quyền
truy cập. Mục tiêu: Trở thành lớp AI layer chính thức cho 1.000 sinh viên VNU-UET.